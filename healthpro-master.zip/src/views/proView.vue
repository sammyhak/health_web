<template>
  <div class="about">
    <!-- <h1>This is an about page</h1> -->
    <thirdProducts></thirdProducts>

  </div>
</template>
<script>

import thirdProducts from '@/components/thirdProduct.vue';
export default {
  name: 'proView',

  components: {
    thirdProducts
  }
}
</script>