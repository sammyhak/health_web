<template>
  <div class="container cf">
    <div class="row container c">
      <div class="col-md-6 col-12">

        <p class="p-tag-class">Healthline Limited is a company registered in 2008 by Pharm Ramchandra Badgujar and Pharm
          Amara Chikwendu; and located at No, 29 Adeniyi Jones Avenue, Ikeja Lagos, Nigeria. Commercial Operation in the
          company Started in 2012 with medical tourism business where over 500 patients were treated successfully at the
          partner Hospital in India.
          Pharmaceutical importation and distribution started in 2013 and in 2015 Avacare Health International – South
          Africa joins the company as a strategic investor.</p>
      </div>
      <div class="col-4"></div>
      
    </div>

  </div>
</template>

<script>
import "../styles/components/AboutUs.scss";
export default {
  name: 'AboutSecond'
}
</script>

<style>
@media (min-width: 769px) and (max-width : 1200px) {}</style>