<template >
    <div class="fp">
        <div class="container mt-5 mb-5 pt-5">
       <div class="row">
            <div class="col-md-4 col-12">
                <P class="fe">Frequently asked Questions about getting medications</P>
            </div>
            <div class="col-md-4 col-12">
                <p class="p-how">How do i get my medication delivered
to my location. </p>
<p class="ou">Our products will be delivered to requested location via our trusted courier agency FEDEX EXPRESS (Red star logistics)  with there offices all over the country. </p>

<P class="p-how">Is there extra charges for product  delivery</P>
                <p class="ou">No extra charge for product delivery.</p>
            </div>
            
            
            <div class="col-md-4 col-12">
                <h6 class="p-how"> How safe is my medications during 
transportation </h6>
                <p class="ou">Our courier agency (FEDEX express) delivers each product in accordance with the medically specified condition of transportation for each product. they are also a group of well-trained logistics experts with several years of experience in medical delivery services. you can trust your product are in good hands.</p>
            </div>
       </div>
    </div>
    </div>
   
</template>

<script>


export default {
name:'FreQuent',

}
</script>

<style>
template{
    /* background-color: brown !important; */
}
.fp{
    background-color: #F3F3F3 !important;
}
.fe{
    font-size:40px;
    color:black !important;
}
.p-how{
    font-size:19px;
    font-weight:800;
}
.ou{
    font-size:14px;
}
</style>