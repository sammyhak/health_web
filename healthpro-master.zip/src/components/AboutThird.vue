<template>
  <div>
    <div class="container company" id="section1">
    <div class="row g-0">
        <div class="col-md-4 col-12">
            <div>
                <h6 class="hyu">
                Head Office
            </h6>
            <p>126 Bode Adams Lorem Ipsulm</p>
            <p>+234 801 2345 6789</p>
            </div>
            <div class="mt-3">
                <h6 class="hyu">
                Branch Office
            </h6>
            <p>126 Bode Adams Lorem Ipsulm</p>
            <p>+234 801 2345 6789</p>
            </div>
            <div class="mt-3">
                <h6 class="hyu">
                Email
            </h6>
            <p>info@companyname.com</p>
            
            </div>
          
        </div>
        <div class="col-md-4 col-12 company-photos">
            <img src="../assets/DSC_0019 1.png" class="container-fluid id">
            <img src="../assets/Frame 1171276973.png" class="container-fluid">
            
        </div>
        <div class="col-md-4 col-12 company-photos">
            <!-- <img src="../assets/DSC_0042 1.png " class="container-fluid"> -->
            <img src="../assets/DSC_0042 1.png" class="container-fluid id">
            <img src="../assets//Frame 1171276974.png" class="container-fluid">
        </div>
    </div>
    </div>
  </div>
</template>

<script>
import "../styles/components/AboutUs.scss";
export default {
  nam:'AboutThird'
}
</script>

<style>
.id{
    margin-bottom:24px;
}
.hyu{
    font-weight:600;
}
</style>